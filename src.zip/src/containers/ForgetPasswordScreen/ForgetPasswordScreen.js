import React from 'react';
import {
  SafeAreaView,
  Image,
  Text,
  View,
  TouchableOpacity,
  StyleSheet,
} from 'react-native';
import CustomButton from '../../components/CustomButton';
import EmailInput from '../../components/EmailInput';
import Images from '../../constants/Images';
import styles from '../ForgetPasswordScreen/styles';

class ForgetPasswordScreen extends React.Component {
  render() {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.marginBox}>
          <TouchableOpacity
            onPress={() => this.props.navigation.navigate('SignIn')}>
            <Image style={styles.backIcon} source={Images.back_arrow} />
          </TouchableOpacity>
          <Image source={Images.logo} style={styles.logo} />

          <Text style={styles.SignUp}>Forgot Password?</Text>
          <Text style={styles.Details}>
            Don’t worry! enter your registered email ID in order to receive
            reset password instructions.
          </Text>
          <View style={styles.InputLayout}>
            <EmailInput placeholder="Email Address" />
          </View>
          <CustomButton
            title="Submit"
            onPress={() => this.props.navigation.navigate('Verification')}
          />
        </View>
      </SafeAreaView>
    );
  }
}

export default ForgetPasswordScreen;
