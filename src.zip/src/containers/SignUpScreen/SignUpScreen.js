import React from 'react';
import {
  SafeAreaView,
  Image,
  Text,
  View,
  TouchableOpacity,
  StyleSheet,
} from 'react-native';
import CustomButton from '../../components/CustomButton';
import EmailInput from '../../components/EmailInput';
import PasswordTextInput from '../../components/PasswordTextInput';
import CustomTextInput from '../../components/CustomTextInput';
import Images from '../../constants/Images';
import styles from '../SignUpScreen/styles';

class SignUpScreen extends React.Component {
  render() {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.marginBox}>
          <TouchableOpacity
            onPress={() => this.props.navigation.navigate('SignIn')}>
            <Image style={styles.backIcon} source={Images.back_arrow} />
          </TouchableOpacity>
          <Image source={Images.logo} style={styles.logo} />

          <Text style={styles.SignUp}>Sign Up</Text>
          <View style={styles.InputLayout}>
            <CustomTextInput placeholder="Name" />
            <CustomTextInput placeholder="User Name" />
            <EmailInput placeholder="Email Address" />
            <PasswordTextInput placeholder="Create Password" />
          </View>

          <View style={styles.Term}>
            <Text style={styles.TermText}>I agree to the</Text>
            <TouchableOpacity>
              <Text style={{...styles.TermText, color: 'rgb(255,152,3)'}}>
                {' '}
                Terms & Conditions{' '}
              </Text>
            </TouchableOpacity>
            <Text style={styles.TermText}>of PhotoLoot</Text>
          </View>
          <View style={styles.InputLayout}>
            <CustomButton title="Submit" />
          </View>
        </View>
      </SafeAreaView>
    );
  }
}

export default SignUpScreen;
