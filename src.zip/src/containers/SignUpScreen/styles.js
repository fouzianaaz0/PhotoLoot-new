import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'rgb(255, 255, 255)',
  },
  logo: {
    height: 125,
    width: 125,
    alignSelf: 'center',
    justifyContent: 'center',
  },
  orConnectWith: {
    fontSize: 15,
    fontWeight: 'normal',
    fontStyle: 'normal',
    letterSpacing: 0,
    textAlign: 'left',
    color: '#919191',
    justifyContent: 'center',
    alignSelf: 'center',
    marginTop: 30,
  },
  forgetPassword: {
    fontSize: 15,
    fontWeight: '600',
    fontStyle: 'normal',
    letterSpacing: 0,
    textAlign: 'right',
    color: '#9d9d9d',
    justifyContent: 'flex-end',
    marginTop: 20,
  },
  marginBox: {
    margin: 20,
  },
  SignUp: {
    marginTop: 28.5,
    fontSize: 25,
    fontWeight: '900',
    textAlign: 'left',
  },
  Term: {
    marginTop: 34.5,
    flexDirection: 'row',
    justifyContent: 'center',
  },
  TermText: {
    fontSize: 12.5,
    fontWeight: 'normal',
    fontStyle: 'normal',
    letterSpacing: 0,
    textAlign: 'left',
    color: 'rgb(96 ,96, 96)',
  },
  backIcon: {
    height: 30,
    width: 30,
  },
  InputLayout: {
    marginTop: 10,
  },
});

export default styles;
