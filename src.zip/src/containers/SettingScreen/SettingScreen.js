import React from 'react';
import {Text, View, TextInput} from 'react-native';

class SettingScreen extends React.Component {
  render() {
    return (
      <View>
        <Text>Hello</Text>
      </View>
    );
  }
}
export default SettingScreen;
