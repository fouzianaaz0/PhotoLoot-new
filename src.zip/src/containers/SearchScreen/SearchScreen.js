import React from 'react';
import {Text, View, TextInput} from 'react-native';

class SearchScreen extends React.Component {
  render() {
    return (
      <View>
        <Text>Hello</Text>
      </View>
    );
  }
}
export default SearchScreen;
