import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'rgb(255, 255, 255)',
  },
  logoI: {
    height: 125,
    width: 125,
    alignSelf: 'center',
    justifyContent: 'center',
    marginTop: 10,
  },
  SignInText: {
    marginTop: 28.5,
    fontSize: 25,
    fontWeight: '900',
    textAlign: 'left',
  },
  orConnectWith: {
    fontSize: 15,
    fontWeight: 'normal',
    fontStyle: 'normal',
    letterSpacing: 0,
    textAlign: 'left',
    color: '#919191',
    justifyContent: 'center',
    alignSelf: 'center',
    marginTop: 30,
  },
  forgetPassword: {
    fontSize: 15,
    fontWeight: '600',
    fontStyle: 'normal',
    letterSpacing: 0,
    textAlign: 'right',
    color: '#9d9d9d',
    justifyContent: 'flex-end',
    marginTop: 20,
  },
  InputMargin: {
    marginTop: 10,
  },
  marginBox: {
    margin: 20,
  },
  SignUpText: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 43.5,
  },
  AccountText: {
    color: 'rgb(96,96,96)',
    fontSize: 15,
  },
  SignUp: {
    color: 'rgb(255,152,3)',
    fontSize: 15,
    fontWeight: '700',
  },
  Eye: {position: 'absolute', top: 75, right: 20},
  EyeColor: {marginTop: 15, height: 15, width: 22},
});

export default styles;
