import React from 'react';
import {
  SafeAreaView,
  Image,
  Text,
  View,
  TouchableOpacity,
  StyleSheet,
} from 'react-native';
import CustomButton from '../../components/CustomButton';
import EmailInput from '../../components/EmailInput';
import PasswordTextInput from '../../components/PasswordTextInput';
import SocialCustomButton from '../../components/SocialCustomButton';
import Images from '../../constants/Images';
import styles from '../SignInScreen/styles';

class SignInScreen extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      hidePassword: true,
      img: require('../../assets/Images/icEyeInactive.png'),
    };

    setPasswordVisiblity = () => {
      if (this.state.hidePassword)
        this.setState({
          hidePassword: !this.state.hidePassword,
          img: require('../../assets/Images/icEyeActive.png'),
        });
      else {
        this.setState({
          hidePassword: !this.state.hidePassword,
          img: require('../../assets/Images/icEyeInactive.png'),
        });
      }
    };
  }
  render() {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.marginBox}>
          <Image source={Images.logo} style={styles.logoI} />
          <Text style={styles.SignInText}>Sign In</Text>
          <View style={styles.InputMargin}>
            <EmailInput placeholder="Email Address" />
            <PasswordTextInput
              placeholder="Password"
              secureTextEntry={this.state.hidePassword}
            />
            <TouchableOpacity style={styles.Eye} onPress={setPasswordVisiblity}>
              <Image style={styles.EyeColor} source={this.state.img} />
            </TouchableOpacity>
          </View>
          <TouchableOpacity
            onPress={() => this.props.navigation.navigate('ForgetPassword')}>
            <Text style={styles.forgetPassword}>Forget Password</Text>
          </TouchableOpacity>
          <CustomButton
            title="Submit"
            onPress={() => this.props.navigation.navigate('HomeScreen')}
          />
          <Text style={styles.orConnectWith}>or Connect with</Text>
          <View style={{flexDirection: 'row', justifyContent: 'space-evenly'}}>
            <SocialCustomButton Image={Images.facebook_Icon} Title="Facebook" />
            <SocialCustomButton
              Image={Images.instagram_Icon}
              Title="Instagram"
            />
          </View>
          <View style={styles.SignUpText}>
            <Text style={styles.AccountText}>Don’t have an account?</Text>
            <TouchableOpacity
              onPress={() => this.props.navigation.navigate('SignUpScreen')}>
              <Text style={styles.SignUp}>Sign Up</Text>
            </TouchableOpacity>
          </View>
        </View>
      </SafeAreaView>
    );
  }
}

export default SignInScreen;
