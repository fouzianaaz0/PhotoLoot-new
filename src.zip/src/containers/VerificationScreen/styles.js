import {StyleSheet} from 'react-native';
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'rgb(255, 255, 255)',
  },
  logo: {
    height: 125,
    width: 125,
    alignSelf: 'center',
    justifyContent: 'center',
  },
  Details: {
    fontSize: 15,
    fontWeight: 'normal',
    fontStyle: 'normal',
    lineHeight: 21,
    textAlign: 'left',
    letterSpacing: 0,
    color: '#9d9d9d',
    marginTop: 20,
  },
  marginBox: {
    margin: 20,
  },
  SignUp: {
    marginTop: 28.5,
    fontSize: 25,
    fontWeight: '900',
    textAlign: 'left',
  },
  backIcon: {
    height: 30,
    width: 30,
  },
  OtpText: {
    color: 'rgb(96,96,96)',
    fontSize: 15,
  },
  ResendOtpView: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 49.5,
  },
  ResendText: {
    color: 'rgb(255,152,3)',
    fontSize: 15,
    fontWeight: '700',
  },
  InputLayout: {
    marginTop: 10,
  },
});

export default styles;
